# setpoint_accel

- File: `mavros/src/plugins/setpoint_accel.cpp`
- Class: `mavros::std_plugins::SetpointAccelerationPlugin`
- Namespace: `setpoint_accel`
- Brief: Setpoint acceleration/force plugin


Send setpoint accelerations/forces to FCU controller.

## Publishers
- None


## Subscribers
- `~/accel` ([geometry_msgs::msg::Vector3Stamped](https://docs.ros.org/en/rolling/p/geometry_msgs/msg/Vector3Stamped.html))


## Services
- None


## Clients
- None


## Parameters
- `send_force` [type: bool, default: `false`]


## MAVLink Subscriptions
- None


## MAVLink Publications
- [`SET_POSITION_TARGET_LOCAL_NED`](https://mavlink.io/en/messages/common.html#SET_POSITION_TARGET_LOCAL_NED) [arg: `sp`, dialect: common, msg_id: 84, id: `mavlink::common::msg::SET_POSITION_TARGET_LOCAL_NED::MSG_ID`]
